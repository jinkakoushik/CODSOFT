import { useState } from "react";
import {
  Check,
  Eye,
  EyeOff,
  ArrowRight,
  ChevronLeft,
  Shield,
  Zap,
  Heart,
  Sparkles,
} from "lucide-react";

const INTERESTS = [
  "Technology", "Design", "Travel", "Food & Drink", "Fitness",
  "Music", "Photography", "Gaming", "Finance", "Books",
  "Cooking", "Fashion", "Science", "Sports", "Wellness",
];

type Step = 0 | 1 | 2 | 3 | 4;

function ProgressDots({ current }: { current: number }) {
  return (
    <div className="flex gap-1.5">
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          className="h-1.5 rounded-full transition-all duration-500"
          style={{
            width: i === current ? 24 : 6,
            background:
              i === current
                ? "#A78BFA"
                : i < current
                ? "rgba(167,139,250,0.4)"
                : "rgba(255,255,255,0.12)",
          }}
        />
      ))}
    </div>
  );
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <label className="block text-[10px] font-semibold text-gray-400 uppercase tracking-widest mb-1.5">
      {children}
    </label>
  );
}

function TextInput({
  type = "text",
  placeholder,
  value,
  onChange,
  error,
  suffix,
}: {
  type?: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  error?: string;
  suffix?: React.ReactNode;
}) {
  return (
    <div>
      <div className="relative">
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full rounded-2xl px-4 py-3.5 text-[15px] outline-none transition-all border"
          style={{
            background: error ? "#FEF2F2" : "#F9FAFB",
            borderColor: error ? "#FCA5A5" : "transparent",
            color: "#111827",
            fontFamily: "'Figtree', sans-serif",
          }}
          onFocus={(e) => {
            if (!error) e.target.style.borderColor = "#7C3AED";
            e.target.style.background = "#fff";
          }}
          onBlur={(e) => {
            if (!error) e.target.style.borderColor = "transparent";
            if (!error) e.target.style.background = "#F9FAFB";
          }}
        />
        {suffix && (
          <div className="absolute right-4 top-1/2 -translate-y-1/2">{suffix}</div>
        )}
      </div>
      {error && <p className="text-red-500 text-xs mt-1.5 pl-1">{error}</p>}
    </div>
  );
}

function PrimaryButton({
  onClick,
  disabled,
  children,
}: {
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="w-full rounded-2xl py-[15px] font-semibold text-[15px] flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
      style={{
        background: disabled
          ? "#E5E7EB"
          : "linear-gradient(135deg, #7C3AED 0%, #6D28D9 100%)",
        color: disabled ? "#9CA3AF" : "#fff",
        fontFamily: "'Figtree', sans-serif",
        boxShadow: disabled ? "none" : "0 8px 24px rgba(124,58,237,0.35)",
        cursor: disabled ? "not-allowed" : "pointer",
      }}
    >
      {children}
    </button>
  );
}

function ScreenHeader({
  onBack,
  step,
  title,
  subtitle,
}: {
  onBack: () => void;
  step: number;
  title: React.ReactNode;
  subtitle: string;
}) {
  return (
    <div className="px-6 pt-5 pb-7 flex-shrink-0">
      <button
        onClick={onBack}
        className="flex items-center gap-1 text-[#9CA3AF] text-sm mb-5 hover:text-white transition-colors"
        style={{ fontFamily: "'Figtree', sans-serif" }}
      >
        <ChevronLeft size={16} />
        Back
      </button>
      <ProgressDots current={step} />
      <p
        className="text-[10px] font-semibold uppercase tracking-widest mt-5 mb-1"
        style={{ color: "#A78BFA" }}
      >
        Step {step + 1} of 3
      </p>
      <h2
        className="text-white mb-1"
        style={{
          fontFamily: "'Outfit', sans-serif",
          fontSize: 26,
          fontWeight: 800,
          lineHeight: 1.1,
        }}
      >
        {title}
      </h2>
      <p className="text-sm" style={{ color: "#9CA3AF" }}>
        {subtitle}
      </p>
    </div>
  );
}

function WhitePanel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex-1 bg-white rounded-t-[32px] px-6 pt-7 pb-8 flex flex-col overflow-hidden">
      {children}
    </div>
  );
}

export default function App() {
  const [step, setStep] = useState<Step>(0);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const toggleInterest = (item: string) => {
    setSelected((prev) =>
      prev.includes(item)
        ? prev.filter((i) => i !== item)
        : prev.length < 5
        ? [...prev, item]
        : prev
    );
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (step === 1) {
      if (!name.trim()) e.name = "Please enter your name";
      if (!email.includes("@") || !email.includes("."))
        e.email = "Enter a valid email address";
    }
    if (step === 2) {
      if (password.length < 8)
        e.password = "Must be at least 8 characters";
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (!validate()) return;
    setErrors({});
    setStep((s) => Math.min(s + 1, 4) as Step);
  };

  const back = () => {
    setErrors({});
    setStep((s) => Math.max(s - 1, 0) as Step);
  };

  const reset = () => {
    setStep(0);
    setName("");
    setEmail("");
    setPassword("");
    setSelected([]);
    setErrors({});
  };

  const strengthLevel =
    password.length === 0
      ? 0
      : password.length < 6
      ? 1
      : password.length < 10
      ? 2
      : /[A-Z]/.test(password) && /[0-9!@#$%]/.test(password)
      ? 4
      : 3;

  const strengthMeta = [
    { label: "", color: "#E5E7EB" },
    { label: "Weak", color: "#EF4444" },
    { label: "Fair", color: "#F97316" },
    { label: "Good", color: "#22C55E" },
    { label: "Strong", color: "#16A34A" },
  ][strengthLevel];

  const firstName = name.split(" ")[0] || "friend";

  return (
    <div
      className="min-h-screen flex items-center justify-center bg-background p-4"
      style={{ fontFamily: "'Figtree', sans-serif" }}
    >
      {/* Phone shell */}
      <div
        className="w-[375px] h-[720px] rounded-[44px] overflow-hidden flex flex-col"
        style={{
          background: "#1C1B22",
          boxShadow:
            "0 0 0 4px #1C1B22, 0 40px 80px rgba(0,0,0,0.4), 0 0 0 5px rgba(255,255,255,0.06)",
        }}
      >
        {/* Status bar */}
        <div
          className="flex justify-between items-center px-8 pt-3.5 pb-1 flex-shrink-0"
          style={{ color: "#9CA3AF", fontSize: 12 }}
        >
          <span style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 600 }}>
            9:41
          </span>
          <div className="flex items-center gap-1">
            {/* Signal */}
            <svg width="16" height="10" viewBox="0 0 16 10" fill="none">
              <rect x="0" y="6" width="3" height="4" rx="0.5" fill="currentColor" opacity="0.4" />
              <rect x="4.5" y="4" width="3" height="6" rx="0.5" fill="currentColor" opacity="0.7" />
              <rect x="9" y="2" width="3" height="8" rx="0.5" fill="currentColor" />
              <rect x="13.5" y="0" width="2.5" height="10" rx="0.5" fill="currentColor" />
            </svg>
            {/* Battery */}
            <div
              className="w-[22px] h-[11px] border rounded-[2px] relative flex items-center px-[2px]"
              style={{ borderColor: "currentColor" }}
            >
              <div
                className="h-[5px] rounded-[1px]"
                style={{ width: "75%", background: "currentColor" }}
              />
              <div
                className="absolute -right-[3px] top-1/2 -translate-y-1/2 h-[5px] w-[2px] rounded-r-[1px]"
                style={{ background: "currentColor", opacity: 0.5 }}
              />
            </div>
          </div>
        </div>

        {/* ── WELCOME ────────────────────────────────────── */}
        {step === 0 && (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Hero */}
            <div className="flex-1 flex flex-col items-center justify-center px-8 pb-4 relative">
              {/* Glow blobs */}
              <div
                className="absolute rounded-full pointer-events-none"
                style={{
                  top: -60,
                  right: -60,
                  width: 220,
                  height: 220,
                  background: "radial-gradient(circle, rgba(124,58,237,0.3) 0%, transparent 70%)",
                  filter: "blur(40px)",
                }}
              />
              <div
                className="absolute rounded-full pointer-events-none"
                style={{
                  bottom: 20,
                  left: -40,
                  width: 180,
                  height: 180,
                  background: "radial-gradient(circle, rgba(109,40,217,0.2) 0%, transparent 70%)",
                  filter: "blur(50px)",
                }}
              />

              {/* Logo */}
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-7"
                style={{
                  background: "linear-gradient(135deg, #7C3AED 0%, #5B21B6 100%)",
                  boxShadow: "0 12px 32px rgba(124,58,237,0.45)",
                }}
              >
                <Zap size={26} color="white" fill="white" />
              </div>

              <h1
                className="text-center mb-3"
                style={{
                  fontFamily: "'Outfit', sans-serif",
                  fontSize: 30,
                  fontWeight: 900,
                  color: "#F9FAFB",
                  lineHeight: 1.1,
                }}
              >
                Your world,
                <br />
                personalized.
              </h1>
              <p
                className="text-center text-sm leading-relaxed"
                style={{ color: "#9CA3AF", maxWidth: 260 }}
              >
                Sign up in under a minute and get an experience built just for you.
              </p>

              {/* Feature list */}
              <div className="mt-7 w-full flex flex-col gap-2.5">
                {[
                  { icon: <Zap size={13} />, label: "Quick 3-step setup" },
                  { icon: <Heart size={13} />, label: "Tailored to your interests" },
                  { icon: <Shield size={13} />, label: "Your data stays private" },
                ].map(({ icon, label }) => (
                  <div
                    key={label}
                    className="flex items-center gap-3 px-4 py-2.5 rounded-xl"
                    style={{
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.07)",
                    }}
                  >
                    <span style={{ color: "#A78BFA" }}>{icon}</span>
                    <span className="text-sm" style={{ color: "#D1D5DB" }}>
                      {label}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom panel */}
            <div className="bg-white rounded-t-[32px] px-6 pt-6 pb-7 flex-shrink-0">
              <PrimaryButton onClick={next}>
                Get started <ArrowRight size={17} />
              </PrimaryButton>
              <p className="text-center text-xs mt-4" style={{ color: "#9CA3AF" }}>
                Already have an account?{" "}
                <span
                  className="font-semibold cursor-pointer"
                  style={{ color: "#7C3AED" }}
                >
                  Sign in
                </span>
              </p>
            </div>
          </div>
        )}

        {/* ── PROFILE ────────────────────────────────────── */}
        {step === 1 && (
          <div className="flex-1 flex flex-col overflow-hidden">
            <ScreenHeader
              onBack={back}
              step={0}
              title="Hey there!"
              subtitle="Create your account to get started"
            />
            <WhitePanel>
              <div className="flex flex-col gap-4 flex-1">
                <div>
                  <FieldLabel>Full name</FieldLabel>
                  <TextInput
                    placeholder="Alex Rivera"
                    value={name}
                    onChange={setName}
                    error={errors.name}
                  />
                </div>
                <div>
                  <FieldLabel>Email address</FieldLabel>
                  <TextInput
                    type="email"
                    placeholder="alex@example.com"
                    value={email}
                    onChange={setEmail}
                    error={errors.email}
                  />
                </div>
                <p className="text-xs leading-relaxed" style={{ color: "#9CA3AF" }}>
                  By continuing you agree to our{" "}
                  <span className="font-medium cursor-pointer" style={{ color: "#7C3AED" }}>
                    Terms
                  </span>{" "}
                  and{" "}
                  <span className="font-medium cursor-pointer" style={{ color: "#7C3AED" }}>
                    Privacy Policy
                  </span>
                  .
                </p>
              </div>
              <div className="mt-auto pt-4">
                <PrimaryButton onClick={next}>
                  Continue <ArrowRight size={17} />
                </PrimaryButton>
              </div>
            </WhitePanel>
          </div>
        )}

        {/* ── PASSWORD ───────────────────────────────────── */}
        {step === 2 && (
          <div className="flex-1 flex flex-col overflow-hidden">
            <ScreenHeader
              onBack={back}
              step={1}
              title="Keep it safe"
              subtitle={`Pick a strong password, ${firstName}`}
            />
            <WhitePanel>
              <div className="flex flex-col gap-4 flex-1">
                <div>
                  <FieldLabel>Password</FieldLabel>
                  <TextInput
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={setPassword}
                    error={errors.password}
                    suffix={
                      <button
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => setShowPassword((v) => !v)}
                        className="text-gray-400 hover:text-gray-600 transition-colors"
                      >
                        {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                      </button>
                    }
                  />

                  {/* Strength bar */}
                  {password.length > 0 && (
                    <div className="mt-3">
                      <div className="flex gap-1.5 mb-1.5">
                        {[1, 2, 3, 4].map((i) => (
                          <div
                            key={i}
                            className="flex-1 h-1.5 rounded-full transition-all duration-300"
                            style={{
                              background:
                                i <= strengthLevel
                                  ? strengthMeta.color
                                  : "#E5E7EB",
                            }}
                          />
                        ))}
                      </div>
                      <p
                        className="text-xs font-medium transition-colors"
                        style={{ color: strengthMeta.color }}
                      >
                        {strengthMeta.label} password
                      </p>
                    </div>
                  )}
                </div>

                {/* Requirements checklist */}
                <div
                  className="rounded-2xl p-4 flex flex-col gap-2.5"
                  style={{ background: "#F9FAFB" }}
                >
                  {[
                    { label: "At least 8 characters", met: password.length >= 8 },
                    {
                      label: "One uppercase letter",
                      met: /[A-Z]/.test(password),
                    },
                    { label: "One number or symbol", met: /[0-9!@#$%]/.test(password) },
                  ].map(({ label, met }) => (
                    <div key={label} className="flex items-center gap-2.5">
                      <div
                        className="w-[18px] h-[18px] rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300"
                        style={{
                          background: met ? "#22C55E" : "#E5E7EB",
                        }}
                      >
                        {met && <Check size={10} color="white" strokeWidth={3} />}
                      </div>
                      <span
                        className="text-xs transition-colors"
                        style={{ color: met ? "#374151" : "#9CA3AF" }}
                      >
                        {label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="mt-auto pt-4">
                <PrimaryButton onClick={next}>
                  Continue <ArrowRight size={17} />
                </PrimaryButton>
              </div>
            </WhitePanel>
          </div>
        )}

        {/* ── INTERESTS ──────────────────────────────────── */}
        {step === 3 && (
          <div className="flex-1 flex flex-col overflow-hidden">
            <ScreenHeader
              onBack={back}
              step={2}
              title={
                <>
                  What do you{" "}
                  <span style={{ color: "#A78BFA" }}>love?</span>
                </>
              }
              subtitle={`Pick up to 5 interests, ${firstName}`}
            />
            <WhitePanel>
              <div className="flex-1 overflow-y-auto scrollbar-none -mx-1 px-1 pb-2">
                <div className="flex flex-wrap gap-2">
                  {INTERESTS.map((item) => {
                    const isOn = selected.includes(item);
                    return (
                      <button
                        key={item}
                        onClick={() => toggleInterest(item)}
                        className="px-3.5 py-2 rounded-full text-sm font-medium transition-all duration-200 active:scale-95"
                        style={{
                          background: isOn
                            ? "linear-gradient(135deg, #7C3AED 0%, #6D28D9 100%)"
                            : "#F3F4F6",
                          color: isOn ? "#fff" : "#374151",
                          boxShadow: isOn
                            ? "0 4px 12px rgba(124,58,237,0.3)"
                            : "none",
                          border: "1.5px solid",
                          borderColor: isOn ? "#6D28D9" : "transparent",
                        }}
                      >
                        {item}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div className="flex-shrink-0 pt-4">
                <p
                  className="text-center text-xs mb-3 font-medium"
                  style={{ color: "#9CA3AF" }}
                >
                  {selected.length === 0
                    ? "Select at least one interest"
                    : `${selected.length} of 5 selected`}
                </p>
                <PrimaryButton onClick={next} disabled={selected.length === 0}>
                  {selected.length === 0 ? "Select an interest" : "Complete setup"}
                  {selected.length > 0 && <ArrowRight size={17} />}
                </PrimaryButton>
              </div>
            </WhitePanel>
          </div>
        )}

        {/* ── DONE ───────────────────────────────────────── */}
        {step === 4 && (
          <div className="flex-1 flex flex-col items-center justify-center px-8 text-center relative overflow-hidden">
            {/* Glow */}
            <div
              className="absolute rounded-full pointer-events-none"
              style={{
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                width: 300,
                height: 300,
                background:
                  "radial-gradient(circle, rgba(124,58,237,0.2) 0%, transparent 65%)",
                filter: "blur(30px)",
              }}
            />

            <div className="relative flex flex-col items-center">
              {/* Check circle */}
              <div
                className="w-20 h-20 rounded-full flex items-center justify-center mb-5"
                style={{
                  background: "linear-gradient(135deg, #22C55E 0%, #16A34A 100%)",
                  boxShadow: "0 12px 32px rgba(34,197,94,0.35)",
                }}
              >
                <Check size={34} color="white" strokeWidth={2.5} />
              </div>

              {/* Sparkle icon */}
              <div
                className="absolute -top-1 -right-3 w-7 h-7 rounded-full flex items-center justify-center"
                style={{ background: "#2A2833" }}
              >
                <Sparkles size={14} color="#A78BFA" />
              </div>

              <h2
                className="mb-2"
                style={{
                  fontFamily: "'Outfit', sans-serif",
                  fontSize: 28,
                  fontWeight: 900,
                  color: "#F9FAFB",
                  lineHeight: 1.1,
                }}
              >
                Welcome,
                <br />
                <span style={{ color: "#A78BFA" }}>{firstName}!</span>
              </h2>
              <p className="text-sm leading-relaxed mb-6" style={{ color: "#9CA3AF" }}>
                Your account is all set. We&apos;ve personalized your
                experience based on your interests.
              </p>

              {/* Interest tags */}
              {selected.length > 0 && (
                <div className="flex flex-wrap gap-1.5 justify-center mb-7">
                  {selected.map((item) => (
                    <span
                      key={item}
                      className="text-xs px-3 py-1.5 rounded-full font-medium"
                      style={{
                        background: "rgba(124,58,237,0.15)",
                        color: "#A78BFA",
                        border: "1px solid rgba(124,58,237,0.25)",
                      }}
                    >
                      {item}
                    </span>
                  ))}
                </div>
              )}

              <button
                onClick={reset}
                className="w-full rounded-2xl py-[15px] font-semibold text-[15px] transition-all active:scale-[0.98]"
                style={{
                  background: "linear-gradient(135deg, #7C3AED 0%, #6D28D9 100%)",
                  color: "#fff",
                  fontFamily: "'Figtree', sans-serif",
                  boxShadow: "0 8px 24px rgba(124,58,237,0.35)",
                }}
              >
                Start exploring →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
