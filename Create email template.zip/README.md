
  # Create email template

  This is a code bundle for Create email template. The original project is available at https://www.figma.com/design/I67Nsk7tky0pNf4lFoxZa4/Create-email-template.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  