import { useState } from "react";
import { Mail, Eye, Smartphone, Monitor, Tablet, Star, Zap, Shield, ArrowRight, CheckCircle2 } from "lucide-react";

type DeviceMode = "desktop" | "tablet" | "mobile";
type Template = "launch" | "promo" | "newsletter";

const templates = {
  launch: {
    label: "Product Launch",
    accent: "#ff6b47",
    bg: "#fff9f7",
    heroGradient: "linear-gradient(135deg, #1a0a00 0%, #3d1a0a 50%, #ff6b47 100%)",
    heroTitle: "Introducing Spark 2.0",
    heroSub: "The fastest way to build, ship, and scale your ideas. Now with AI-powered suggestions, real-time collaboration, and zero config deploys.",
    heroCta: "Get Early Access",
    features: [
      { icon: "⚡", title: "10× Faster Builds", desc: "Our new compiler pipeline slashes build times to under 3 seconds, even for large monorepos." },
      { icon: "🤖", title: "AI Co-pilot", desc: "Inline suggestions, auto-complete, and intelligent refactoring — trained on 100M lines of production code." },
      { icon: "🔒", title: "Enterprise Security", desc: "SOC 2 Type II certified, end-to-end encryption, and granular access controls built in from day one." },
    ],
  },
  promo: {
    label: "Promo Sale",
    accent: "#4f46e5",
    bg: "#f5f4ff",
    heroGradient: "linear-gradient(135deg, #0f0a2e 0%, #1e1660 50%, #4f46e5 100%)",
    heroTitle: "Summer Sale — 40% Off",
    heroSub: "For 72 hours only. Upgrade to Pro and unlock unlimited projects, priority support, and the full AI suite. No code needed.",
    heroCta: "Claim My Discount",
    features: [
      { icon: "🎁", title: "Unlimited Projects", desc: "Remove all project caps and ship as many products as your team can dream up, at no extra cost." },
      { icon: "🚀", title: "Priority Queue", desc: "Your builds jump to the front of the line. Get results in seconds, not minutes, when it counts most." },
      { icon: "📊", title: "Advanced Analytics", desc: "Full-funnel dashboards, cohort analysis, and A/B test results — all in one place, updated in real time." },
    ],
  },
  newsletter: {
    label: "Newsletter",
    accent: "#059669",
    bg: "#f0fdf8",
    heroGradient: "linear-gradient(135deg, #022c22 0%, #064e3b 50%, #059669 100%)",
    heroTitle: "This Week in Tech",
    heroSub: "Your curated digest of the most important stories, tools, and ideas shaping the future of software. Hand-picked every Friday.",
    heroCta: "Read This Week's Issue",
    features: [
      { icon: "📰", title: "5 Must-Reads", desc: "We filter through 300+ sources so you get only the signal — no noise, no clickbait, no filler." },
      { icon: "🛠️", title: "Tool of the Week", desc: "One carefully vetted tool that our editorial team actually uses and recommends from first-hand experience." },
      { icon: "💡", title: "Thought Piece", desc: "A short, original essay from our rotating roster of founders, engineers, and researchers in the field." },
    ],
  },
};

const deviceWidths: Record<DeviceMode, string> = {
  desktop: "100%",
  tablet: "600px",
  mobile: "375px",
};

export default function App() {
  const [template, setTemplate] = useState<Template>("launch");
  const [device, setDevice] = useState<DeviceMode>("desktop");

  const t = templates[template];

  return (
    <div
      className="min-h-screen bg-background text-foreground"
      style={{ fontFamily: "'Outfit', sans-serif" }}
    >
      {/* Decorative geometry */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute -top-24 -right-24 w-96 h-96 rounded-full opacity-10"
          style={{ background: "radial-gradient(circle, #ff6b47 0%, transparent 70%)" }}
        />
        <div
          className="absolute top-1/2 -left-32 w-64 h-64 rotate-45 opacity-5"
          style={{ background: "#4f46e5", borderRadius: "30% 70% 70% 30% / 30% 30% 70% 70%" }}
        />
        <div
          className="absolute bottom-0 right-1/3 w-48 h-48 opacity-5"
          style={{ background: "#ffcd29", clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)" }}
        />
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: t.accent }}
          >
            <Mail size={16} className="text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight">MailCraft</span>
          <span
            className="text-xs px-2 py-0.5 rounded-full font-medium"
            style={{ background: t.accent + "22", color: t.accent }}
          >
            Template Studio
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Eye size={15} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Live Preview</span>
        </div>
      </header>

      {/* Toolbar */}
      <div className="relative z-10 border-b border-border bg-card/60 backdrop-blur-sm px-6 py-3 flex flex-wrap items-center gap-4">
        {/* Template selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Template</span>
          <div className="flex gap-1">
            {(Object.keys(templates) as Template[]).map((key) => (
              <button
                key={key}
                onClick={() => setTemplate(key)}
                className="px-3 py-1.5 rounded-md text-sm font-medium transition-all duration-150"
                style={
                  template === key
                    ? { background: t.accent, color: "#fff" }
                    : { background: "transparent", color: "var(--muted-foreground)" }
                }
              >
                {templates[key].label}
              </button>
            ))}
          </div>
        </div>

        <div className="h-4 w-px bg-border hidden sm:block" />

        {/* Device toggle */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Preview</span>
          <div className="flex gap-1 bg-secondary rounded-lg p-0.5">
            {([
              { mode: "desktop" as DeviceMode, Icon: Monitor },
              { mode: "tablet" as DeviceMode, Icon: Tablet },
              { mode: "mobile" as DeviceMode, Icon: Smartphone },
            ]).map(({ mode, Icon }) => (
              <button
                key={mode}
                onClick={() => setDevice(mode)}
                className="p-1.5 rounded-md transition-all duration-150"
                style={
                  device === mode
                    ? { background: t.accent, color: "#fff" }
                    : { color: "var(--muted-foreground)" }
                }
              >
                <Icon size={14} />
              </button>
            ))}
          </div>
        </div>

        <div className="ml-auto">
          <button
            className="flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-semibold text-white transition-all duration-150 hover:opacity-90 active:scale-95"
            style={{ background: t.accent }}
          >
            Use Template <ArrowRight size={14} />
          </button>
        </div>
      </div>

      {/* Preview area */}
      <main className="relative z-10 p-6 md:p-10 flex justify-center">
        <div
          className="transition-all duration-300 ease-in-out"
          style={{ width: deviceWidths[device], maxWidth: "100%" }}
        >
          {/* Browser chrome */}
          <div className="rounded-xl overflow-hidden shadow-2xl border border-border" style={{ boxShadow: "0 32px 80px rgba(0,0,0,0.5)" }}>
            {/* Chrome bar */}
            <div className="bg-secondary px-4 py-3 flex items-center gap-3 border-b border-border">
              <div className="flex gap-1.5">
                <span className="w-3 h-3 rounded-full bg-red-400" />
                <span className="w-3 h-3 rounded-full bg-yellow-400" />
                <span className="w-3 h-3 rounded-full bg-green-400" />
              </div>
              <div className="flex-1 bg-muted rounded-md px-3 py-1 text-xs text-muted-foreground flex items-center gap-2">
                <span>📧</span>
                <span style={{ fontFamily: "'Inter', sans-serif" }}>
                  {t.heroTitle} — {t.label}
                </span>
              </div>
            </div>

            {/* Email client pane */}
            <div className="bg-[#f0f0f2] flex" style={{ minHeight: "600px" }}>
              {/* Sidebar (hidden on mobile) */}
              {device === "desktop" && (
                <aside className="w-52 bg-[#e8e8ec] border-r border-black/5 flex-shrink-0 py-4 px-3">
                  <div className="text-[11px] font-semibold text-[#888] uppercase tracking-wider mb-3 px-2">Inbox</div>
                  {["Promotions", "Updates", "Forums", "Spam"].map((folder, i) => (
                    <div
                      key={folder}
                      className="px-2 py-1.5 rounded-md mb-0.5 text-sm flex items-center justify-between"
                      style={
                        i === 0
                          ? { background: t.accent + "22", color: t.accent, fontWeight: 600 }
                          : { color: "#555" }
                      }
                    >
                      {folder}
                      {i === 0 && (
                        <span
                          className="text-[10px] px-1.5 py-0.5 rounded-full text-white font-bold"
                          style={{ background: t.accent }}
                        >
                          3
                        </span>
                      )}
                    </div>
                  ))}
                </aside>
              )}

              {/* Email body */}
              <div className="flex-1 overflow-auto bg-[#f7f7f9] p-4 md:p-6">
                <EmailTemplate t={t} accent={t.accent} compact={device === "mobile"} />
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Feature callouts */}
      <section className="relative z-10 px-6 md:px-10 pb-16 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-4xl mx-auto">
        {[
          { Icon: Zap, label: "Instant Preview", desc: "Switch templates and devices without a single page reload." },
          { Icon: Star, label: "Pixel Perfect", desc: "Every element aligned to a 4px grid, tested across 14 clients." },
          { Icon: Shield, label: "Spam-safe HTML", desc: "Inline styles and table-based fallbacks for maximum deliverability." },
        ].map(({ Icon, label, desc }) => (
          <div key={label} className="bg-card border border-border rounded-xl p-5 group hover:border-primary/30 transition-colors duration-200">
            <div
              className="w-9 h-9 rounded-lg flex items-center justify-center mb-3"
              style={{ background: t.accent + "18" }}
            >
              <Icon size={18} style={{ color: t.accent }} />
            </div>
            <div className="font-semibold text-sm mb-1">{label}</div>
            <div className="text-xs text-muted-foreground leading-relaxed" style={{ fontFamily: "'Inter', sans-serif" }}>{desc}</div>
          </div>
        ))}
      </section>
    </div>
  );
}

function EmailTemplate({
  t,
  accent,
  compact,
}: {
  t: (typeof templates)[Template];
  accent: string;
  compact: boolean;
}) {
  return (
    <div
      className="mx-auto rounded-lg overflow-hidden shadow-md"
      style={{
        maxWidth: compact ? "100%" : "600px",
        background: "#ffffff",
        fontFamily: "'Inter', sans-serif",
      }}
    >
      {/* Email header */}
      <div className="px-6 py-4 border-b flex items-center justify-between" style={{ borderColor: "#eee" }}>
        <div className="flex items-center gap-2">
          <div
            className="w-6 h-6 rounded flex items-center justify-center"
            style={{ background: accent }}
          >
            <Mail size={12} className="text-white" />
          </div>
          <span className="font-bold text-sm" style={{ color: "#111" }}>MailCraft</span>
        </div>
        <span className="text-xs" style={{ color: "#999" }}>noreply@mailcraft.io</span>
      </div>

      {/* Hero */}
      <div
        className="relative flex flex-col items-center justify-center text-center px-8 py-14"
        style={{ background: t.heroGradient, minHeight: "260px" }}
      >
        {/* Memphis dots */}
        <div className="absolute top-4 right-4 w-3 h-3 rounded-full opacity-40" style={{ background: "#ffcd29" }} />
        <div className="absolute top-8 right-8 w-2 h-2 rounded-full opacity-30" style={{ background: "#ffffff" }} />
        <div className="absolute bottom-6 left-6 w-4 h-4 rotate-45 opacity-20" style={{ background: "#ffffff" }} />

        <div
          className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-4 uppercase tracking-widest"
          style={{ background: accent + "33", color: accent === "#ff6b47" ? "#ffb3a0" : accent === "#4f46e5" ? "#a5b4fc" : "#6ee7b7", border: `1px solid ${accent}44` }}
        >
          {t.label}
        </div>
        <h1
          className="font-extrabold leading-tight mb-4"
          style={{
            fontSize: compact ? "22px" : "32px",
            color: "#ffffff",
            fontFamily: "'Outfit', sans-serif",
            letterSpacing: "-0.02em",
          }}
        >
          {t.heroTitle}
        </h1>
        <p
          className="mb-8 leading-relaxed"
          style={{ color: "rgba(255,255,255,0.75)", fontSize: compact ? "13px" : "15px", maxWidth: "420px" }}
        >
          {t.heroSub}
        </p>
        <a
          href="#"
          className="inline-block font-bold rounded-lg px-8 py-3 text-white transition-opacity hover:opacity-90"
          style={{
            background: accent,
            fontSize: "14px",
            fontFamily: "'Outfit', sans-serif",
            textDecoration: "none",
            letterSpacing: "0.02em",
          }}
        >
          {t.heroCta} →
        </a>
      </div>

      {/* Section label */}
      <div className="px-8 pt-10 pb-4">
        <div className="flex items-center gap-3">
          <div className="h-px flex-1" style={{ background: "#eee" }} />
          <span className="text-xs font-semibold uppercase tracking-widest" style={{ color: "#bbb" }}>What's included</span>
          <div className="h-px flex-1" style={{ background: "#eee" }} />
        </div>
      </div>

      {/* Features */}
      <div className="px-8 pb-8 grid grid-cols-1 gap-5">
        {t.features.map((f) => (
          <div
            key={f.title}
            className="flex gap-4 p-5 rounded-xl"
            style={{ background: t.bg, border: `1px solid ${accent}18` }}
          >
            <span className="text-2xl flex-shrink-0 mt-0.5">{f.icon}</span>
            <div>
              <div className="font-semibold text-sm mb-1" style={{ color: "#111", fontFamily: "'Outfit', sans-serif" }}>
                {f.title}
              </div>
              <div className="text-xs leading-relaxed" style={{ color: "#666" }}>
                {f.desc}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Social proof */}
      <div className="mx-8 mb-8 p-5 rounded-xl flex items-start gap-3" style={{ background: "#f9f9fb" }}>
        <CheckCircle2 size={18} style={{ color: accent, flexShrink: 0, marginTop: "1px" }} />
        <div>
          <div className="text-xs font-semibold mb-0.5" style={{ color: "#111" }}>Trusted by 24,000+ teams</div>
          <div className="text-xs" style={{ color: "#888" }}>
            From indie hackers to Fortune 500 companies — MailCraft powers over 180M emails per month with 99.97% deliverability.
          </div>
        </div>
      </div>

      {/* CTA strip */}
      <div
        className="px-8 py-8 text-center"
        style={{ background: accent + "0d", borderTop: `2px solid ${accent}22` }}
      >
        <div className="font-bold text-base mb-1" style={{ color: "#111", fontFamily: "'Outfit', sans-serif" }}>
          Ready to get started?
        </div>
        <div className="text-xs mb-5" style={{ color: "#888" }}>
          No credit card required. Cancel anytime.
        </div>
        <a
          href="#"
          className="inline-block font-bold rounded-lg px-7 py-2.5 text-white"
          style={{ background: accent, fontSize: "13px", textDecoration: "none", fontFamily: "'Outfit', sans-serif" }}
        >
          {t.heroCta}
        </a>
      </div>

      {/* Footer */}
      <div className="px-8 py-6 text-center border-t" style={{ borderColor: "#eee" }}>
        <div className="text-xs mb-2" style={{ color: "#aaa" }}>
          MailCraft Inc., 340 Pine Street, Suite 801, San Francisco, CA 94104
        </div>
        <div className="text-xs" style={{ color: "#bbb" }}>
          You received this email because you signed up at mailcraft.io.{" "}
          <a href="#" style={{ color: accent, textDecoration: "none" }}>Unsubscribe</a>
          {" · "}
          <a href="#" style={{ color: accent, textDecoration: "none" }}>Privacy Policy</a>
        </div>
      </div>
    </div>
  );
}
