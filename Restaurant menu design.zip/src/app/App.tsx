import { useState, useEffect, useRef } from "react";
import { ShoppingBag, X, Plus, Minus, ChevronRight, Leaf, Star } from "lucide-react";

type Tag = "vegetarian" | "gluten-free" | "chef-special" | "spicy";

interface Dish {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  tags: Tag[];
  categoryId: string;
}

interface Category {
  id: string;
  label: string;
  subtitle: string;
}

const categories: Category[] = [
  { id: "starters", label: "Starters", subtitle: "Begin the journey" },
  { id: "soups", label: "Soups & Salads", subtitle: "Light & fresh" },
  { id: "mains", label: "Main Course", subtitle: "Hearty selections" },
  { id: "pasta", label: "Pasta & Risotto", subtitle: "Comfort classics" },
  { id: "desserts", label: "Desserts", subtitle: "Sweet endings" },
  { id: "drinks", label: "Drinks", subtitle: "Fine pairings" },
];

const dishes: Dish[] = [
  // Starters
  {
    id: "s1",
    name: "Burrata & Heirloom Tomatoes",
    description: "Creamy burrata with sun-kissed heirloom tomatoes, basil oil, and Maldon sea salt on toasted sourdough.",
    price: 160,
    image: "https://images.unsplash.com/photo-1778855646167-d56c50631f8d?w=480&h=360&fit=crop&auto=format",
    tags: ["vegetarian", "chef-special"],
    categoryId: "starters",
  },
  {
    id: "s2",
    name: "Seared Scallops",
    description: "Pan-seared diver scallops with cauliflower purée, crispy capers, and brown butter vinaigrette.",
    price: 220,
    image: "https://images.unsplash.com/photo-1558679582-4d81ce75993a?w=480&h=360&fit=crop&auto=format",
    tags: ["gluten-free"],
    categoryId: "starters",
  },
  {
    id: "s3",
    name: "Spiced Duck Crostini",
    description: "Slow-rendered duck confit on crisp crostini with fig jam, pickled shallots, and microgreens.",
    price: 190,
    image: "https://images.unsplash.com/photo-1720636615079-1841bcaaec84?w=480&h=360&fit=crop&auto=format",
    tags: ["spicy"],
    categoryId: "starters",
  },
  // Soups & Salads
  {
    id: "ss1",
    name: "French Onion Gratinée",
    description: "Slow-cooked caramelized onions in a rich beef consommé, crowned with aged Gruyère and crusty baguette.",
    price: 140,
    image: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=480&h=360&fit=crop&auto=format",
    tags: ["chef-special"],
    categoryId: "soups",
  },
  {
    id: "ss2",
    name: "Niçoise Salad",
    description: "Line-caught tuna, haricots verts, Niçoise olives, soft-boiled egg, and potato with Dijon vinaigrette.",
    price: 180,
    image: "https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=480&h=360&fit=crop&auto=format",
    tags: ["gluten-free"],
    categoryId: "soups",
  },
  {
    id: "ss3",
    name: "Roasted Beet & Endive",
    description: "Golden and ruby beets with Belgian endive, candied walnuts, chèvre, and blood orange dressing.",
    price: 150,
    image: "https://images.unsplash.com/photo-1689672235501-6dc1e56d454c?w=480&h=360&fit=crop&auto=format",
    tags: ["vegetarian", "gluten-free"],
    categoryId: "soups",
  },
  // Mains
  {
    id: "m1",
    name: "Côte de Bœuf",
    description: "32oz dry-aged prime rib-eye with pomme purée, roasted bone marrow, and a Bordelaise reduction.",
    price: 580,
    image: "https://images.unsplash.com/photo-1663530761401-15eefb544889?w=480&h=360&fit=crop&auto=format",
    tags: ["chef-special", "gluten-free"],
    categoryId: "mains",
  },
  {
    id: "m2",
    name: "Pan-Roasted Halibut",
    description: "Wild Pacific halibut with saffron beurre blanc, fennel confit, and crispy artichoke hearts.",
    price: 420,
    image: "https://images.unsplash.com/photo-1676471926534-d5c9771909fa?w=480&h=360&fit=crop&auto=format",
    tags: ["gluten-free"],
    categoryId: "mains",
  },
  {
    id: "m3",
    name: "Herb-Crusted Rack of Lamb",
    description: "Dijon and herbed breadcrumb-crusted rack of lamb with flageolet beans and rosemary jus.",
    price: 490,
    image: "https://images.unsplash.com/photo-1621494268492-d01b98eba7e4?w=480&h=360&fit=crop&auto=format",
    tags: ["chef-special"],
    categoryId: "mains",
  },
  // Pasta & Risotto
  {
    id: "p1",
    name: "Cacio e Pepe",
    description: "Hand-rolled tonnarelli with aged Pecorino Romano, Parmigiano-Reggiano, and Tellicherry black pepper.",
    price: 260,
    image: "https://images.unsplash.com/photo-1633337474564-1d9478ca4e2e?w=480&h=360&fit=crop&auto=format",
    tags: ["vegetarian", "chef-special"],
    categoryId: "pasta",
  },
  {
    id: "p2",
    name: "Squid Ink Linguine",
    description: "House-made squid ink pasta with Calabrian chili, cherry tomatoes, bottarga, and grilled calamari.",
    price: 320,
    image: "https://images.unsplash.com/photo-1617474020181-e1d42f2245ea?w=480&h=360&fit=crop&auto=format",
    tags: ["spicy"],
    categoryId: "pasta",
  },
  {
    id: "p3",
    name: "Porcini Risotto",
    description: "Carnaroli rice slow-cooked with wild porcini, Barolo wine reduction, truffle oil, and aged Parmesan.",
    price: 280,
    image: "https://images.unsplash.com/photo-1644921504851-b8861be402ac?w=480&h=360&fit=crop&auto=format",
    tags: ["vegetarian", "gluten-free"],
    categoryId: "pasta",
  },
  // Desserts
  {
    id: "d1",
    name: "Valrhona Chocolate Fondant",
    description: "Warm bittersweet chocolate fondant with a molten centre, Tahitian vanilla crème anglaise, and cacao nibs.",
    price: 140,
    image: "https://images.unsplash.com/photo-1626263468007-a9e0cf83f1ac?w=480&h=360&fit=crop&auto=format",
    tags: ["chef-special"],
    categoryId: "desserts",
  },
  {
    id: "d2",
    name: "Crème Brûlée",
    description: "Classic Madagascan vanilla custard with a caramelized sugar crust and seasonal berries.",
    price: 120,
    image: "https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=480&h=360&fit=crop&auto=format",
    tags: ["vegetarian", "gluten-free"],
    categoryId: "desserts",
  },
  // Drinks
  {
    id: "dr1",
    name: "Sommelier's Wine Pairing",
    description: "Four curated pours selected by our sommelier to complement each course. Ask your server for this evening's selection.",
    price: 650,
    image: "https://images.unsplash.com/photo-1509710398975-6454dcdf049f?w=480&h=360&fit=crop&auto=format",
    tags: ["gluten-free"],
    categoryId: "drinks",
  },
  {
    id: "dr2",
    name: "Elderflower Spritz",
    description: "St-Germain elderflower liqueur, Fever-Tree cucumber tonic, fresh mint, and a squeeze of yuzu.",
    price: 140,
    image: "https://images.unsplash.com/photo-1689672235501-6dc1e56d454c?w=480&h=360&fit=crop&auto=format",
    tags: ["vegetarian"],
    categoryId: "drinks",
  },
];

const TAG_CONFIG: Record<Tag, { label: string; color: string }> = {
  vegetarian: { label: "V", color: "bg-emerald-100 text-emerald-800" },
  "gluten-free": { label: "GF", color: "bg-amber-100 text-amber-800" },
  "chef-special": { label: "Chef's", color: "bg-[#B85C3A]/10 text-[#B85C3A]" },
  spicy: { label: "Spicy", color: "bg-red-100 text-red-800" },
};

export default function App() {
  const [activeCategory, setActiveCategory] = useState("starters");
  const [cart, setCart] = useState<Record<string, number>>({});
  const [cartOpen, setCartOpen] = useState(false);
  const sectionRefs = useRef<Record<string, HTMLElement | null>>({});

  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0);
  const cartTotal = Object.entries(cart).reduce((total, [id, qty]) => {
    const dish = dishes.find((d) => d.id === id);
    return total + (dish?.price ?? 0) * qty;
  }, 0);

  function addToCart(id: string) {
    setCart((prev) => ({ ...prev, [id]: (prev[id] ?? 0) + 1 }));
  }

  function removeFromCart(id: string) {
    setCart((prev) => {
      const next = { ...prev };
      if ((next[id] ?? 0) <= 1) delete next[id];
      else next[id] = next[id] - 1;
      return next;
    });
  }

  function scrollToCategory(id: string) {
    setActiveCategory(id);
    sectionRefs.current[id]?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveCategory(entry.target.id);
          }
        });
      },
      { rootMargin: "-30% 0px -60% 0px" }
    );
    Object.values(sectionRefs.current).forEach((el) => el && observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const cartItems = Object.entries(cart).map(([id, qty]) => ({
    dish: dishes.find((d) => d.id === id)!,
    qty,
  }));

  return (
    <div
      className="flex h-screen overflow-hidden"
      style={{ fontFamily: "'Jost', sans-serif", backgroundColor: "#FAF6F0" }}
    >
      {/* Sidebar */}
      <aside
        className="w-64 flex-shrink-0 flex flex-col overflow-y-auto"
        style={{
          backgroundColor: "#2C1810",
          color: "#FAF6F0",
          scrollbarWidth: "none",
        }}
      >
        {/* Restaurant identity */}
        <div className="px-8 pt-10 pb-8 border-b border-white/10">
          <p
            className="text-xs tracking-[0.25em] uppercase text-white/40 mb-1"
            style={{ fontFamily: "'Jost', sans-serif" }}
          >
            Est. 1987
          </p>
          <h1
            className="text-2xl leading-tight text-white"
            style={{ fontFamily: "'Fraunces', serif", fontWeight: 400 }}
          >
            Le Jardin
            <br />
            <em className="text-[#B85C3A] not-italic" style={{ fontStyle: "italic" }}>
              Maison
            </em>
          </h1>
          <p className="mt-3 text-xs text-white/40 leading-relaxed tracking-wide">
            Contemporary French cuisine in the heart of the city
          </p>
        </div>

        {/* Category nav */}
        <nav className="flex-1 px-5 py-6">
          <p
            className="text-[10px] tracking-[0.2em] uppercase text-white/30 px-3 mb-4"
            style={{ fontFamily: "'Jost', sans-serif" }}
          >
            Menu
          </p>
          <ul className="space-y-1">
            {categories.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <li key={cat.id}>
                  <button
                    onClick={() => scrollToCategory(cat.id)}
                    className="w-full text-left px-3 py-2.5 rounded-sm flex items-center justify-between group transition-all duration-200"
                    style={{
                      backgroundColor: isActive ? "rgba(184, 92, 58, 0.15)" : "transparent",
                      color: isActive ? "#F4C89E" : "rgba(250, 246, 240, 0.55)",
                    }}
                  >
                    <div>
                      <p
                        className="text-sm leading-none mb-0.5 transition-colors"
                        style={{
                          fontFamily: "'Fraunces', serif",
                          fontWeight: isActive ? 500 : 400,
                          color: isActive ? "#F4C89E" : undefined,
                        }}
                      >
                        {cat.label}
                      </p>
                      <p className="text-[10px] opacity-50">{cat.subtitle}</p>
                    </div>
                    {isActive && (
                      <ChevronRight
                        size={12}
                        style={{ color: "#B85C3A" }}
                        className="flex-shrink-0"
                      />
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Reservation callout */}
        <div className="mx-5 mb-6 p-4 rounded-sm" style={{ backgroundColor: "rgba(184, 92, 58, 0.12)", border: "1px solid rgba(184, 92, 58, 0.25)" }}>
          <p
            className="text-xs text-white/70 mb-2 leading-snug"
            style={{ fontFamily: "'Fraunces', serif", fontStyle: "italic" }}
          >
            Reserve your table for an unforgettable evening
          </p>
          <button
            className="text-[10px] tracking-widest uppercase text-[#B85C3A] hover:text-[#F4C89E] transition-colors"
            style={{ fontFamily: "'Jost', sans-serif", fontWeight: 600 }}
          >
            Book Now →
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main
        className="flex-1 overflow-y-auto relative"
        style={{ scrollbarWidth: "none" }}
      >
        {/* Top bar */}
        <div
          className="sticky top-0 z-20 flex items-center justify-between px-10 py-5"
          style={{
            backgroundColor: "rgba(250, 246, 240, 0.92)",
            backdropFilter: "blur(12px)",
            borderBottom: "1px solid rgba(44, 24, 16, 0.08)",
          }}
        >
          <div>
            <p
              className="text-lg"
              style={{ fontFamily: "'Fraunces', serif", color: "#1C1208" }}
            >
              {categories.find((c) => c.id === activeCategory)?.label}
            </p>
          </div>
          <button
            onClick={() => setCartOpen(true)}
            className="relative flex items-center gap-2.5 px-5 py-2.5 rounded-sm text-sm transition-all duration-200 hover:opacity-80"
            style={{
              backgroundColor: "#2C1810",
              color: "#FAF6F0",
              fontFamily: "'Jost', sans-serif",
              fontWeight: 500,
            }}
          >
            <ShoppingBag size={15} />
            <span>Order</span>
            {cartCount > 0 && (
              <span
                className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold"
                style={{ backgroundColor: "#B85C3A", color: "white" }}
              >
                {cartCount}
              </span>
            )}
          </button>
        </div>

        {/* Sections */}
        <div className="px-10 pb-20">
          {categories.map((cat) => {
            const catDishes = dishes.filter((d) => d.categoryId === cat.id);
            return (
              <section
                key={cat.id}
                id={cat.id}
                ref={(el) => { sectionRefs.current[cat.id] = el; }}
                className="pt-12 mb-4"
              >
                <div className="mb-8">
                  <p
                    className="text-xs tracking-[0.25em] uppercase mb-2"
                    style={{ color: "#B85C3A", fontFamily: "'Jost', sans-serif", fontWeight: 600 }}
                  >
                    {cat.subtitle}
                  </p>
                  <h2
                    className="text-3xl"
                    style={{ fontFamily: "'Fraunces', serif", fontWeight: 400, color: "#1C1208" }}
                  >
                    {cat.label}
                  </h2>
                  <div className="mt-3 h-px w-12" style={{ backgroundColor: "#B85C3A" }} />
                </div>

                <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
                  {catDishes.map((dish) => {
                    const qty = cart[dish.id] ?? 0;
                    return (
                      <div
                        key={dish.id}
                        className="group flex gap-5 rounded-sm overflow-hidden transition-all duration-300 hover:shadow-md"
                        style={{
                          backgroundColor: "#FFF9F4",
                          border: "1px solid rgba(44, 24, 16, 0.08)",
                        }}
                      >
                        {/* Image */}
                        <div
                          className="w-32 flex-shrink-0 overflow-hidden"
                          style={{ backgroundColor: "#EDE5D8" }}
                        >
                          <img
                            src={dish.image}
                            alt={dish.name}
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                            style={{ minHeight: "120px" }}
                          />
                        </div>

                        {/* Info */}
                        <div className="flex-1 py-4 pr-4 flex flex-col justify-between min-w-0">
                          <div>
                            <div className="flex items-start justify-between gap-2 mb-1.5">
                              <h3
                                className="text-base leading-snug"
                                style={{ fontFamily: "'Fraunces', serif", fontWeight: 500, color: "#1C1208" }}
                              >
                                {dish.name}
                              </h3>
                              <span
                                className="text-sm font-medium flex-shrink-0"
                                style={{ fontFamily: "'Jost', sans-serif", color: "#B85C3A", fontWeight: 600 }}
                              >
                                ₹{dish.price}
                              </span>
                            </div>
                            <p
                              className="text-xs leading-relaxed mb-3"
                              style={{ color: "#7A6553", fontFamily: "'Jost', sans-serif" }}
                            >
                              {dish.description}
                            </p>
                            <div className="flex flex-wrap gap-1.5 mb-3">
                              {dish.tags.map((tag) => (
                                <span
                                  key={tag}
                                  className={`text-[9px] tracking-widest uppercase px-2 py-0.5 rounded-sm font-semibold ${TAG_CONFIG[tag].color}`}
                                  style={{ fontFamily: "'Jost', sans-serif" }}
                                >
                                  {TAG_CONFIG[tag].label}
                                </span>
                              ))}
                            </div>
                          </div>

                          {/* Cart controls */}
                          <div className="flex items-center gap-2">
                            {qty === 0 ? (
                              <button
                                onClick={() => addToCart(dish.id)}
                                className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-sm transition-all duration-200 hover:opacity-80"
                                style={{
                                  backgroundColor: "#2C1810",
                                  color: "#FAF6F0",
                                  fontFamily: "'Jost', sans-serif",
                                  fontWeight: 500,
                                  letterSpacing: "0.05em",
                                }}
                              >
                                <Plus size={11} /> Add
                              </button>
                            ) : (
                              <div
                                className="flex items-center gap-2 rounded-sm overflow-hidden"
                                style={{ border: "1px solid rgba(44, 24, 16, 0.15)" }}
                              >
                                <button
                                  onClick={() => removeFromCart(dish.id)}
                                  className="w-7 h-7 flex items-center justify-center hover:bg-black/5 transition-colors"
                                >
                                  <Minus size={11} style={{ color: "#1C1208" }} />
                                </button>
                                <span
                                  className="text-sm w-4 text-center"
                                  style={{ fontFamily: "'Jost', sans-serif", fontWeight: 600, color: "#1C1208" }}
                                >
                                  {qty}
                                </span>
                                <button
                                  onClick={() => addToCart(dish.id)}
                                  className="w-7 h-7 flex items-center justify-center hover:bg-black/5 transition-colors"
                                >
                                  <Plus size={11} style={{ color: "#1C1208" }} />
                                </button>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>
      </main>

      {/* Cart drawer overlay */}
      {cartOpen && (
        <div
          className="fixed inset-0 z-50 flex"
          onClick={() => setCartOpen(false)}
        >
          <div className="flex-1" />
          <div
            className="w-96 h-full flex flex-col shadow-2xl"
            style={{ backgroundColor: "#FFF9F4" }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Cart header */}
            <div
              className="flex items-center justify-between px-7 py-6"
              style={{ borderBottom: "1px solid rgba(44, 24, 16, 0.1)" }}
            >
              <h2
                className="text-xl"
                style={{ fontFamily: "'Fraunces', serif", fontWeight: 400, color: "#1C1208" }}
              >
                Your Order
              </h2>
              <button
                onClick={() => setCartOpen(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-black/5 transition-colors"
              >
                <X size={16} style={{ color: "#7A6553" }} />
              </button>
            </div>

            {/* Cart items */}
            <div className="flex-1 overflow-y-auto px-7 py-5" style={{ scrollbarWidth: "none" }}>
              {cartItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-48 text-center">
                  <ShoppingBag size={32} style={{ color: "#C4B5A0", marginBottom: "12px" }} />
                  <p
                    className="text-sm"
                    style={{ color: "#7A6553", fontFamily: "'Fraunces', serif", fontStyle: "italic" }}
                  >
                    Your order is empty.
                    <br />
                    Add something delicious.
                  </p>
                </div>
              ) : (
                <ul className="space-y-4">
                  {cartItems.map(({ dish, qty }) => (
                    <li
                      key={dish.id}
                      className="flex items-center gap-4 pb-4"
                      style={{ borderBottom: "1px solid rgba(44, 24, 16, 0.07)" }}
                    >
                      <div
                        className="w-14 h-14 rounded-sm overflow-hidden flex-shrink-0"
                        style={{ backgroundColor: "#EDE5D8" }}
                      >
                        <img
                          src={dish.image}
                          alt={dish.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p
                          className="text-sm leading-snug"
                          style={{ fontFamily: "'Fraunces', serif", color: "#1C1208" }}
                        >
                          {dish.name}
                        </p>
                        <p
                          className="text-xs mt-0.5"
                          style={{ color: "#7A6553", fontFamily: "'Jost', sans-serif" }}
                        >
                          ₹{dish.price} each
                        </p>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <p
                          className="text-sm font-semibold"
                          style={{ color: "#B85C3A", fontFamily: "'Jost', sans-serif" }}
                        >
                          ₹{dish.price * qty}
                        </p>
                        <div
                          className="flex items-center gap-1.5 rounded-sm overflow-hidden"
                          style={{ border: "1px solid rgba(44, 24, 16, 0.15)" }}
                        >
                          <button
                            onClick={() => removeFromCart(dish.id)}
                            className="w-6 h-6 flex items-center justify-center hover:bg-black/5 transition-colors"
                          >
                            <Minus size={9} style={{ color: "#1C1208" }} />
                          </button>
                          <span
                            className="text-xs w-4 text-center"
                            style={{ fontFamily: "'Jost', sans-serif", fontWeight: 600, color: "#1C1208" }}
                          >
                            {qty}
                          </span>
                          <button
                            onClick={() => addToCart(dish.id)}
                            className="w-6 h-6 flex items-center justify-center hover:bg-black/5 transition-colors"
                          >
                            <Plus size={9} style={{ color: "#1C1208" }} />
                          </button>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            {/* Cart footer */}
            {cartItems.length > 0 && (
              <div
                className="px-7 py-6"
                style={{ borderTop: "1px solid rgba(44, 24, 16, 0.1)" }}
              >
                <div className="flex justify-between items-center mb-1.5">
                  <span
                    className="text-xs uppercase tracking-widest"
                    style={{ color: "#7A6553", fontFamily: "'Jost', sans-serif" }}
                  >
                    Subtotal
                  </span>
                  <span
                    className="text-xl"
                    style={{ fontFamily: "'Fraunces', serif", color: "#1C1208" }}
                  >
                    ₹{cartTotal}
                  </span>
                </div>
                <p
                  className="text-[10px] mb-5"
                  style={{ color: "#B5A090", fontFamily: "'Jost', sans-serif" }}
                >
                  Service and taxes will be added at checkout
                </p>
                <button
                  className="w-full py-3.5 text-sm tracking-widest uppercase rounded-sm transition-all duration-200 hover:opacity-85"
                  style={{
                    backgroundColor: "#2C1810",
                    color: "#FAF6F0",
                    fontFamily: "'Jost', sans-serif",
                    fontWeight: 600,
                    letterSpacing: "0.1em",
                  }}
                >
                  Place Order
                </button>
                <button
                  onClick={() => setCartOpen(false)}
                  className="w-full mt-2.5 py-2.5 text-xs transition-colors hover:opacity-70"
                  style={{ color: "#7A6553", fontFamily: "'Jost', sans-serif" }}
                >
                  Continue browsing
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
