
  # Restaurant menu design

  This is a code bundle for Restaurant menu design. The original project is available at https://www.figma.com/design/7dwvgUr4I2s8gNp360afJq/Restaurant-menu-design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  